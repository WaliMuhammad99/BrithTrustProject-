<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <link rel="stylesheet" href="./css/footer.css">

      <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
    <footer>
        <div class="container">
            <div class="row">

                <div class="col-12 col-md-3">
                    <div>
                        <h1 class="logo">Bright<span>Trust</span></h1>
                        <p>Your trusted online store for quality products at affordable prices.
                             Shop with confidence and enjoy a simple and secure shopping experience.</p>

                         <!-- Social Media -->

                          <div class="social-links">

                              <a href="#" title="Facebook">
                                  f
                               </a>

                              <a href="#" title="Instagram">
                               ◎
                              </a>

                             <a href="#" title="Twitter">
                                 𝕏
                             </a>

                              <a href="#" title="WhatsApp">
                                  ☎
                             </a>

                            </div>
                    </div>

                </div>


                
                     <!-- quick links -->


                  <div class="col-12 col-md-3">
                    <h4>Quick link</h4>
                    <ul>
                        <li>
                            <a href="#">Home</a>
                        </li>

                        <li>
                            <a href="#">Products</a>
                        </li>

                        <li>
                            <a href="#">Catagory</a>
                        </li>

                        <li>
                            <a href="#">About</a>
                        </li>

                        <li>
                            <a href="#">Contact</a>
                        </li>
                    </ul>

                </div>


                 <!-- Catagory -->

                  <div class="col-12 col-md-3">
                    <h4>Catagory</h4>
                    <ul>
                        <li>
                            <a href="#">Shoe</a>
                        </li>

                        <li>
                            <a href="#">Electronics</a>
                        </li>

                        <li>
                            <a href="#">Cloths</a>
                        </li>

                        <li>
                            <a href="#">Accessories</a>
                        </li>

                         <li>
                            <a href="#">books</a>
                        </li>

                    </ul>

                </div>



                 <!-- Contact -->


                <div class="col-12 col-md-3">

                   <h4>Contact</h4>


                   
                      <div class="contact-item">

                         <span>📍</span>
                         Peshawar, Pakistan

                      </div>

                      <div class="contact-item">

                          <span>📞</span>
                          +92 3028836210

                       </div>

                       <div class="contact-item">

                           <span>✉</span>
                           walimuhammad.dev@gmail.com

                       </div>

                </div>


            </div>

        </div>

    </footer>
</body>
</html>