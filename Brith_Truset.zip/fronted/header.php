<?php
include "../backend/connection/connection.php";

if(isset($_GET['searching']))
{
    $search_value = trim($_GET['search_bar']);

    $carry = "SELECT * FROM add_product
              WHERE name LIKE '%$search_value%'
              OR description LIKE '%$search_value%'";

    $result = $conn->query($carry);

    if(!$result){
        die("SQL Error: " . $conn->error);
    }
}
else
{
    $carry = "SELECT * FROM add_product";
    $result = $conn->query($carry);
   
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Header</title>

    <link rel="stylesheet" href="./css/header.css">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

<header class="main-header">

    <div class="container">
        <div class="row align-items-center">

            <!-- Logo -->
            <div class="col-md-2 col-12">
                <h1 class="logo">Brith<span>Trust</span></h1>
            </div>

            <div class="col-md-1 d-none d-md-block"></div>

            <!-- Navigation -->
            <div class="col-md-4 col-12">
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Products</a></li>
                        <li><a href="#">Catagory</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </nav>
            </div>


            <div class="col-md-1 d-none d-md-block"></div>


             
            <!-- Search -->
            <!-- <div class="col-md-3 col-10">
                
            <form method="GET" action="" class="search-box">
                <div class="search-box">
                    <input type="text"
                           class="form-control"
                           name="search_bar"
                           placeholder="Search products...">


                    <button type="submit" name="searching">
                      <i class="bi bi-search"></i>
                    </button>

                </div>
                </form>
            </div> -->



<!-- Search -->
<div class="col-md-3 col-10">

    <form method="GET" action="front.php" class="search-box">

        <input type="text"
               class="form-control"
               name="search_bar"
               placeholder="Search products...">

        <i class="bi bi-search search-icon"
           onclick="this.closest('form').submit()"></i>

        <input type="hidden" name="searching" value="1">

    </form>

</div>





            <!-- Cart -->
            <div class="col-md-1 col-2">
                <a href="#" class="header-icon" title="Shopping Cart">
                    <i class="bi bi-cart3"></i>
                </a>
            </div>

        </div>
    </div>

</header>

</body>
</html>