<?php
include "../backend/connection/connection.php";

// add new
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$product_id = $_GET['id'];
$image = $_GET['image'];
$category = $_GET['category'];
$name = $_GET['name'];
$rating = $_GET['rating'];
$price = $_GET['price'];
$description = $_GET['description'];

if(isset($_POST['submit'])){

    $product_id = $_POST['product_id'];
    $image = $_POST['image'];
    $category = $_POST['category'];
    $name = $_POST['name'];
    $rating = $_POST['rating'];
    // $price = $_POST['price'];
    $description = $_POST['description'];
    $costumar_name = $_POST['costumar_name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];

    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $total = $price * $quantity;

    $save = "INSERT INTO orders(product_id,image,category,name,rating,price,description,costumar_name,email,contact,address,quantity, total)
    VALUES
    ('$product_id','$image','$category','$name','$rating','$price','$description','$costumar_name','$email','$contact','$address','$quantity', '$total')";



    $mail = new PHPMailer(true);

    try {
        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'walimuhammad77king77@gmail.com';
        $mail->Password   = 'xagrmozkdpgsycyt';
        // $mail->Password   = 'azwttwcapwwoxweb';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        // Sender
        $mail->setFrom('walimuhammad77king77@gmail.com', 'Bright Trust');

        // Buyer Email
        $mail->addAddress($email,$costumar_name);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'Order Confirmation';
        $mail->Body = "
            <h2>Hello $name,</h2>
            <p>Thank you for your order.</p>
            <p>Your order has been received successfully.</p>
            <p>You will receive it within 2 to 3 days.</p>
        ";

        $mail->send();

        echo "Order placed successfully and email sent.";

    } catch (Exception $e) {
        echo "Email could not be sent. Error: {$mail->ErrorInfo}";
    }


    // if($conn->query($save)=== TRUE){
    //      echo "<script>alert('Order Place Successfuly')</script>";
    // }

    // else{
    //     echo "<script>alert('Order Does Not Place')</script>";
    // }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>

     <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Your CSS -->

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="./css/order.css">
</head>
<body>

 <?php
    include "./header.php";
    ?>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card-body">

                        
                            <form action="" method="POST">
                                   <div class="header">
                                       <h1>Give Me Your Detail For Order</h1>
                                   </div>
                                <div class="row p-2">

                                    <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $product_id?>" name="product_id">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                            <input type="hidden" class="form-control" value="<?php echo $image?>" name="image">   
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $category?>" name="category">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $name?>" name="name">
                                    </div>

                                     <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $rating?>" name="rating">
                                    </div>

                                     <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $price?>" name="price">
                                    </div>

                                     <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" value="<?php echo $description?>" name="description">
                                    </div>

                                     <div class="col-md-6 mb-3">
                                        <!-- <label for="">Full Name</label> -->
                                        <input type="hidden" class="form-control">
                                    </div>

                                     <div class="col-md-8 mb-3">
                                        <img src="../backend/image/<?php echo $image?>" class="image-size" alt="">
                                    </div>
                                     <div class="col-md-2 mb-2">
                                        <p value="<?php $name?>"></p>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Full Name</label>
                                        <input type="text" class="form-control" name="costumar_name">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Email</label>
                                        <input type="email" class="form-control" name="email">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Contact</label>
                                        <input type="number" class="form-control" name="contact">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Quantity</label>
                                        <input type="number" class="form-control" name="quantity">
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="">Address</label>
                                        <!-- <input type="text" class="form-control" rows="5" name="address"> -->
                                              <textarea
                                                 name="address"class="form-control"rows="4"
                                                 placeholder="Enter your complete delivery address"required></textarea>
                                    </div>

                                    <div class="col-md-10 mb-3">
                                         <button type="submit" class="btn btn-dark w-50" name="submit">
                                           Submit Order
                                        </button>
                                    </div>

                                </div>
                            </form>

                </div>

            </div>

        </div>


    </div>
    
    
 <br><br>
    
     <?php
      include "./footer.php";
    ?>

</body>
</html>