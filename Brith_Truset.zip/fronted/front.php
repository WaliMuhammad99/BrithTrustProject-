
<?php
include "../backend/connection/connection.php";

$carry = "SELECT * FROM add_product";
$result = $conn->query($carry);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="./css/front.css">

   
</head>

<body>
    <?php
    include "./header.php";
    ?>

    <div class="container mt-5">
        <div class="row">

            <?php
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
            ?>

                <div class="col-12 col-sm-6 col-md-3 mb-4">

                    <div class="card">

                        <a href="detail.php?id=<?php echo $row['id']?>&image=<?php echo $row['image']?>&category=<?php echo $row['category']?>&name=<?php echo $row['name']?>&rating=<?php echo $row['rating']?>&review=<?php echo $row['review']?>&price=<?php echo $row['price']?>&description=<?php echo $row['description']?>">


                            <img src="../backend/image/<?php echo $row['image']; ?>"
                                 class="image-width"
                                 alt="No picture">

                            <div class="mt-2">
                                <p>
                                    <?php echo $row['name']; ?>
                                </p>
                            </div>

                            <div class="mt-2">

                                <?php
                                $rating = $row['rating'];

                                for ($i = 1; $i <= 5; $i++){

                                    if($i <= $rating){
                                        echo '<span class="star">★</span>';
                                    }else{
                                        echo '<span class="empty-star">★</span>';
                                    }

                                }
                                ?>

                                <span class="rating-number">
                                    <?php echo $rating; ?>
                                </span>

                            </div>

                            <div class="mt-2">
                                <h4>
                                $<?php echo number_format($row['price'], 2); ?>
                                </h4>
                            </div>
                        </a>
                            
                            <button class="btn btn-dark product-button">
                               Add to Cart
                            </button>
                        
                    </div>

                </div>

            <?php
                }
            }
            ?>

        </div>
    </div>
<br><br>
    <?php
      include "./footer.php";
    ?>
</body>
</html>
