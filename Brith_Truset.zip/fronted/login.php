
<?php
include "../backend/connection/connection.php";
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $login = "SELECT * FROM login WHERE eamil = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $login);
    $row = $result->fetch_assoc();

         if($result->num_rows > 0){
            $_SESSION['username']= $row['name'];
            header("location: deshboard.php");
        }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Brith Trust Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

    <div class="container mt-5">

        <div class="row justify-content-center">

            <div class="col-md-5">

                <div class="card shadow p-4">

                    <h2 class="text-center mb-4">
                        Brith Trust
                    </h2>

                    <h4 class="text-center mb-4">
                        Login
                    </h4>

                    <form action="login.php" method="POST">

                        <!-- Email -->
                        <div class="mb-3">

                            <label class="form-label">
                                Email
                            </label>

                            <input
                                type="email"
                                name="email"
                                class="form-control"
                                placeholder="Enter your email"
                                required
                            >

                        </div>

                        <!-- Password -->
                        <div class="mb-3">

                            <label class="form-label">
                                Password
                            </label>

                            <input
                                type="password"
                                name="password"
                                class="form-control"
                                placeholder="Enter your password"
                                required
                            >

                        </div>

                        <!-- Login Button -->
                        <button
                            type="submit"
                            name="login"
                            class="btn btn-dark w-100">

                            Login

                        </button>

                    </form>

                </div>

            </div>

        </div>

    </div>

</body>

</html>