<?php
include "../backend/connection/connection.php";

$id = $_GET['id'];
$image = $_GET['image'];
$category = $_GET['category'];
$name = $_GET['name'];
$rating = $_GET['rating'];
$review = $_GET['review'];
$price = $_GET['price'];
$description = $_GET['description'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail</title>

     <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Your CSS -->

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="./css/detail.css">
    <style>
      
    </style>
</head>
<body>

    <?php
    include "./header.php";
    ?>

    <div class="container mt-5">

        <div class="row justify-content-center">

            <div class="col-md-10">

                <div class="card p-3">

                     <div class="row">

                         <div class="col-md-7">
                             <img src="../backend/image/<?php echo $image?>" class="image-size" alt="NO picture">
                         </div>

                        <div class="col-md-5">

                                    <div>
                                       <p><?php echo $category?></p>
                                    </div>

                                    <div>
                                        <h1><?php echo $name?></h1>
                                    </div>
                             
                                     <div class="mb-3">
                                          <?php echo $rating?>

                                    <?php

                                         for ($i = 1; $i <= 5; $i++) {

                                         if ($i <= $rating) {

                                         echo '<span class="star">★</span>';

                                         } else {

                                         echo '<span class="empty-star">★</span>';

                                         }

                                      }

                                   ?>

                                     </div>

                                     <div class="mb-3">
                                         <p>(<?php echo $review?>: Review)</p>
                                     </div>

                                     <div class="mb-3">
                                         <h2>$<?php echo $price; ?></h2>
                                     </div>
                             
                                     <div class="mb-3">
                                         <p><?php echo $description?></p>
                                     </div>
                                      <hr>

                                     <div class="mb-3">
                                        <a href="./order.php?id=<?php echo $id?>&image=<?php echo $image?>&category=<?php echo $category?>&name=<?php echo $name?>&rating=<?php echo $rating?>&price=<?php echo $price?>&description=<?php echo $description?>"

                                        class="btn btn-dark">Order Button</a>
                                     </div>

                        </div>


                     </div>

                </div>

            </div>

        </div>

    </div>

    <br><br>
    
     <?php
      include "./footer.php";
    ?>
</body>
</html>