<?php
$conn = new mysqli("localhost","root","","brith_trust");
if($conn->connect_error){
    echo "your connection fail";
}
?>