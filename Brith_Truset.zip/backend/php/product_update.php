
<?php
include "../connection/connection.php";

$uid = $_GET['id'];
$uimage = $_GET['image'];
$uname = $_GET['name'];
$udescription = $_GET['description'];
$ucategory = $_GET['category'];
$uprice = $_GET['price'];
$uold_price = $_GET['old_price'];
$ustock = $_GET['stock'];
$urating = $_GET['rating'];
$ureview = $_GET['review'];

if(isset($_POST['update'])){

    $name = $_POST['name'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $old_price = $_POST['old_price'];
    $stock = $_POST['stock'];
    $rating = $_POST['rating'];
    $review = $_POST['review'];

    // Keep old image
    $image = $uimage;

    // If a new image is selected
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){

        $image = $_FILES['image']['name'];

        move_uploaded_file(
            $_FILES['image']['tmp_name'],
            "../images/" . $image
        );
    }

    $update = "UPDATE add_product SET 
    image = '$image',
    name = '$name',
    description = '$description',
    category = '$category',
    price = '$price',
    old_price = '$old_price',
    stock = '$stock',
    rating = '$rating',
    review = '$review'
    WHERE id = '$uid'";

    if($conn->query($update) == TRUE){

        header("location: add_product.php");
        exit();

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Update</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Your CSS -->
    <link rel="stylesheet" href="../css/product_update.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>

<body>

    <div class="container mt-5">

        <div class="row justify-content-center">

            <div class="col-lg-10">

                <!-- card -->

                <div class="card">

                    <div class="card-header">

                        <h1>Update Your Products Here</h1>

                        <p>This is Brith Trust E-Commerce Store</p>

                    </div>


                    <!-- form body -->

                    <div class="card-body">

                        <form action="" method="POST" enctype="multipart/form-data">

                            <div class="row">

                                <div class="col-md-6 mb-4">

                                    <label for="">ID</label>

                                    <input type="number"
                                        name="id"
                                        class="form-control"
                                        value="<?php echo $uid?>">

                                </div>


                                <div class="col-md-6 mb-4">

                                    <label for="">NAME</label>

                                    <input type="text"
                                        name="name"
                                        class="form-control"
                                        value="<?php echo $uname?>">

                                </div>


                                <div class="col-md-12 mb-3 mb-4">

                                    <label for="">DESCRIPTION</label>

                                    <input type="text"
                                        name="description"
                                        class="form-control"
                                        value="<?php echo $udescription?>">
                                    
                                        <!-- here is problem in textarea -->
                                    <!-- <textarea class="form-control"
                                    value="<?php echo $udescription?>"
                                    name="description"
                                    rows="4"></textarea> -->

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">CATEGORY</label>

                                    <input type="text"
                                        name="category"
                                        class="form-control"
                                        value="<?php echo $ucategory?>">

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">PRICE</label>

                                    <input type="number"
                                        name="price"
                                        class="form-control"
                                        value="<?php echo $uprice?>">

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">OLD_PRICE</label>

                                    <input type="number"
                                        name="old_price"
                                        class="form-control"
                                        value="<?php echo $uold_price?>">

                                </div>


                                <div class="col-12 mb-4">

                                    <label for="">IMAGE</label>

                                    <input type="file"
                                        name="image"
                                        class="form-control">

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">STOCK</label>

                                    <input type="number"
                                        name="stock"
                                        class="form-control"
                                        value="<?php echo $ustock?>">

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">RATING</label>

                                    <input type="number"
                                        name="rating"
                                        class="form-control"
                                        value="<?php echo $urating?>">

                                </div>


                                <div class="col-md-4 mb-4">

                                    <label for="">REVIEWS</label>

                                    <input type="number"
                                        name="review"
                                        class="form-control"
                                        value="<?php echo $ureview?>">

                                </div>


                                <div class="col-6 mb-4">

                                    <button type="submit"
                                        name="update"
                                        class="btn btn-dark mt-4 w-100">
                                        <i class="bi bi-pencil-square"></i>

                                        Update

                                    </button>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

</body>
</html>
