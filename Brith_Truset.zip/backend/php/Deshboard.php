<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

      <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"> -->

    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="stylesheet" href="../css/Deshboard.css">
</head>
<body>


    <div class="container">
        <div class="row justify-content-center">
          
         <div class="col-md-12 mt-5">
            <h1 class=" alert alert-dark animate__animated animate__fadeInDown" id="deshboard">WELCOME TO NAVBAR</h1>

        </div>

            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>NAVBAR</h2>
                         <i class="fa-solid fa-bars"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>SLIDERBAR</h2>
                        <i class="fa-solid fa-window-maximize"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="add_product.php">
                        <h2>PRODUCTS</h2>
                        <i class="fa-solid fa-box"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="order.php">
                        <h2>ORDERS</h2>
                        <i class="fa-solid fa-bag-shopping"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>FOOTER</h2>
                        <i class="fa-solid fa-table-columns"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>HOME</h2>
                        <i class="fa-solid fa-house"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>DELETE</h2>
                        <i class="fa-solid fa-trash"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <a href="">
                        <h2>UPDATE</h2>
                        <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</body>
</html>