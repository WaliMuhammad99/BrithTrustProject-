
<?php
include "../connection/connection.php";


if(isset($_POST['save'])){

    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $old_price = $_POST['old_price'];
    $image = $_FILES['image']['name'];
    $tempory = $_FILES['image']['tmp_name'];
    $stock = $_POST['stock'];
    $rating = $_POST['rating'];
    $review = $_POST['review'];
    $folder = "./image";

    if(move_uploaded_file($tempory,$folder)){
        $save = "INSERT INTO add_product(name, description, category, price, old_price, image, stock, rating, review)
        VALUES
        ('$name', '$description', '$category', '$price', '$old_price', '$image', '$stock', '$rating', '$review')";

        if($conn->query($save)== true){
            echo "<script> alert('Your Product Save Successfuly')</script>";
        }

        else{
            echo"<script> alert ('You have any problem')</script>";
        }
        
    }
}

$select = "SELECT * FROM add_product";
$result = $conn->query($select);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Your CSS -->
    <link rel="stylesheet" href="../css/add_product.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>
<body>

    <div class="container py-5">
        <div class="row justify-content-center">

            <div class="col-lg-10">

                <div class="card">

                    <div class="card-header">
                        <h1>Add New Products Here</h1>
                    </div>


                    <div class="card-body">

                        <form action="" method="POST"enctype="multipart/form-data">

                            <div class="row">

                                <div class="col-md-6 mb-3">
                                    <label for="">Name</label>
                                    <input type="text" name="name" class="form-control">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="">Description</label>
                                    <input type="text" name="description" class="form-control">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="">Category</label>
                                    <input type="text" name="category" class="form-control">
                                </div>

                                <div class="col-md-6">
                                    <label for="">Price</label>
                                    <input type="number" name="price" class="form-control">
                                </div>

                                <div class="col-md-6">
                                    <label for="">Old_Price</label>
                                    <input type="number" name="old_price" class="form-control">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="">Image</label>
                                    <input type="file" name="image" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label for="">Stock</label>
                                    <input type="number" name="stock" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label for="">Rating</label>
                                    <!-- <input type="number" name="rating" class="form-control"> -->
                                    <input type="number"name="rating"min="0"max="5"step="0.1" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label for="">Reviews</label>
                                    <input type="number" name="review" class="form-control">
                                </div>


                                <div class="col-md-6">
                                    <button type="submit" name="save" class="btn btn-dark mt-5 w-100">
                                        <i class="fa-solid fa-floppy-disk"></i>
                                        Save Product
                                    </button>
                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    </div>


    <!-- table -->

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-dark">

                        <tr>
                            <th>ID</th>
                            <th>IMAGE</th>
                            <th>NAME</th>
                            <th>Description</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Old_Price</th>
                            <th>Stock</th>
                            <th>Rating</th>
                            <th>Reviews</th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>

                    </thead>


                    <tbody>

                        <?php

                        if($result->num_rows > 0){

                            while($row = $result->fetch_assoc()){

                        ?>

                        <tr>

                            <td>
                                <?php echo $row['id']?>
                            </td>

                            <td>
                                <img src="../image/<?php echo $row['image']?>"
                                    alt="NO Picture"
                                    width="70"
                                    height="70">
                            </td>

                            <td>
                                <?php echo $row['name']?>
                            </td>

                            <td>
                                <?php echo $row['description']?>
                            </td>

                            <td>
                                <?php echo $row['category']?>
                            </td>

                            <td>
                                <?php echo $row['price']?>
                            </td>

                            <td>
                                <?php echo $row['old_price']?>
                            </td>

                            <td>
                                <?php echo $row['stock']?>
                            </td>

                            <td>
                                <?php echo $row['rating']?>
                            </td>

                            <td>
                                <?php echo $row['review']?>
                            </td>

                            <td>

                                <a href="product_update.php?id=<?php echo $row['id']?>&image=<?php echo urlencode($row['image'])?>&name=<?php echo urlencode($row['name'])?>&description=<?php echo urlencode($row['description'])?>&category=<?php echo urlencode($row['category'])?>&price=<?php echo $row['price']?>&old_price=<?php echo $row['old_price']?>&stock=<?php echo $row['stock']?>&rating=<?php echo $row['rating']?>&review=<?php echo $row['review']?>"
                                    class="btn btn-warning">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                            </td>


                            <td>

                                <a href="delete.php?id=<?php echo $row['id']?>"
                                    class="btn btn-danger"
                                    onclick="return confirm ('Are You Sure You Want To Delete This Product?');">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php

                            }

                        }

                        ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</body>
</html>
