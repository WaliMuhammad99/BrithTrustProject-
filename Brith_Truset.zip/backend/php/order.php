<?php
include "../connection/connection.php";
$carry = "SELECT * FROM orders";
$result = $conn->query($carry);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

      <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"> -->

    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
     <link rel="stylesheet" href="../css/order.css">
 
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-light table-hover">
                    <thead>
                        <tr>
                            <th>IMAGE</th>
                            <th>ID</th>
                            <th>P.ID</th>
                            <th>CATEGORY</th>
                            <th>NAME</th>
                            <th>RATING</th>
                            <th>PRICE</th>
                            <th>DESCRIPTION</th>
                            <th>CLIENT</th>
                            <th>EMAIL</th>
                            <th>CONTACT</th>
                            <th>ADDRESS</th>
                            <th>QUANTITY</th>
                            <th>TOTAL</th>
                            <th>Delete</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        if($result->num_rows > 0){
                            while($row = $result->fetch_assoc()){
                        
                        ?>

                        <tr>
                            <td>
                                <img src="../image/<?php echo $row['image']?>"class="pic-size" alt="">
                            </td>
                            <td><?php echo $row['id']?></td>
                            <td><?php echo $row['product_id']?></td>
                            <td><?php echo $row['category']?></td>
                            <td><?php echo $row['name']?></td>
                            <td><?php echo $row['rating']?></td>
                            <td><?php echo $row['price']?></td>
                            <td><?php echo $row['description']?></td>
                            <td><?php echo $row['costumar_name']?></td>
                            <td><?php echo $row['email']?></td>
                            <td><?php echo $row['contact']?></td>
                            <td><?php echo $row['address']?></td>
                            <td><?php echo $row['quantity']?></td>
                            <td><?php echo $row['total']?></td>
                            <td>
                                <a href="orderdelete.php?id=<?php echo $row['id']?>" class="btn btn-dark">Delete</a>
                            </td>
                        </tr>
                        <?php
                            }
                            }
                        ?>
                    </tbody>
                </table>

              

            </div>

        </div>

    </div>
    
</body>
</html>