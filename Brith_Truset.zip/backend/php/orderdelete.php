

<?php
include "../connection/connection.php";

$id = $_GET['id'];

$delete = mysqli_query($conn, "DELETE FROM orders WHERE id = '$id'");
if($delete){
    header("location: order.php");
}
?>