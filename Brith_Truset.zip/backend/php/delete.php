<?php
include "../connection/connection.php";

$id = $_GET['id'];

$delete = mysqli_query($conn, "DELETE FROM add_product WHERE id = '$id'");
    if($delete){
        header("location: add_product.php");
    }

?>